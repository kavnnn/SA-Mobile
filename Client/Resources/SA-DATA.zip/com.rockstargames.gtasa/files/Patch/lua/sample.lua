ScriptName("Example Script")
ScriptAuthor("Kavn & James")
ScriptVersion("0.1")
ScriptDescription("Example Script using every modules")

local checked = false

function OnConnect()
    -- Your code here
end

function OnDisconnect()
    -- Your code here
end


function OnSAMPPreload()
    -- Your code here
    PrintLog('Example Script Loaded!')
end

function OnSAMPStart()
    SendClientMessage('My Lua Script Loaded!')
end

function OnSAMPClose()
    -- Your code here
end

function OnInterfaceLoad()
    -- Your code here
end

function RenderInterface()
    ImGuiSetNextWindowSize(300, 200)
    local open = true
    if ImGuiBegin("Hello, Lua!",open, 0) then
        ImGuiText("Hello, world!")
        if ImGuiButton("Click me") then
            SendClientMessage("{FFFFFF}Button{FF0000} Clicked!")
        end
        
        if ImGuiCheckbox("Check me", checked) then
            if checked then
                checked = false
            else checked = true
            end
        end
        
        if ImGuiTreeNodeEx("Tree Node") then
            ImGuiText("Inside Tree Node")
            ImGuiEnd()
        end
        ImGuiAddText(0, 0, 255, 0, 0, 255, "Hello from ImGui")
        ImGuiEnd()
    end
    
end